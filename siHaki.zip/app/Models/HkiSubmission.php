<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Helpers\DateTimeHelper;

class HkiSubmission extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'reviewer_id',
        'title',
        'type',
        'creation_type',
        'description',
        'alamat',           // ✅ NEW
        'kode_pos',         // ✅ NEW
        'first_publication_date',
        'additional_data',
        'member_count',
        'status',
        'submission_date',
        'review_notes',
        'reviewed_at',
    ];

    protected $casts = [
        'submission_date' => 'datetime',
        'reviewed_at' => 'datetime',
        'first_publication_date' => 'date',
        'additional_data' => 'array',
    ];

    // ✅ UPDATED: Pisahkan creation types menjadi lebih spesifik
    const CREATION_TYPES = [
        'program_komputer' => 'Program Komputer',
        'sinematografi' => 'Sinematografi',
        'buku' => 'Buku',
        'poster' => 'Poster',
        'fotografi' => 'Fotografi',
        'seni_gambar' => 'Seni Gambar',
        'karakter_animasi' => 'Karakter Animasi',
        'alat_peraga' => 'Alat Peraga',
        'basis_data' => 'Basis Data',
    ];

    const STATUSES = [
        'draft' => 'Draft',
        'submitted' => 'Submitted',
        'under_review' => 'Under Review',
        'revision_needed' => 'Revision Needed',
        'approved' => 'Approved',
        'rejected' => 'Rejected',
    ];

    // Relationships
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function reviewer()
    {
        return $this->belongsTo(User::class, 'reviewer_id');
    }

    public function documents()
    {
        return $this->hasMany(SubmissionDocument::class, 'submission_id');
    }

    public function histories()
    {
        return $this->hasMany(SubmissionHistory::class, 'submission_id');
    }

    public function members()
    {
        return $this->hasMany(SubmissionMember::class, 'submission_id')->orderBy('position');
    }

    public function leader()
    {
        return $this->hasOne(SubmissionMember::class)->where('is_leader', true);
    }

    /**
     * Get main document
     */
    public function mainDocument()
    {
        return $this->hasOne(SubmissionDocument::class, 'submission_id')
                    ->where('document_type', 'main_document');
    }

    /**
     * Get supporting documents
     */
    public function supportingDocuments()
    {
        return $this->hasMany(SubmissionDocument::class, 'submission_id')
                    ->where('document_type', 'supporting_document');
    }

    /**
     * Get certificate
     */
    public function certificate()
    {
        return $this->hasOne(SubmissionDocument::class, 'submission_id')
                    ->where('document_type', 'certificate');
    }

    // Accessors
    public function getCreationTypeNameAttribute()
    {
        return match($this->creation_type) {
            'program_komputer' => 'Program Komputer',
            'sinematografi' => 'Sinematografi',
            'buku' => 'Buku',
            'poster' => 'Poster',
            'fotografi' => 'Fotografi',
            'seni_gambar' => 'Seni Gambar',
            'karakter_animasi' => 'Karakter Animasi',
            'alat_peraga' => 'Alat Peraga',
            'basis_data' => 'Basis Data',
            default => ucfirst(str_replace('_', ' ', $this->creation_type))
        };
    }

    public function getStatusNameAttribute()
    {
        return \App\Helpers\StatusHelper::getStatusName($this->status);
    }

    public function getStatusColorAttribute()
    {
        $colors = [
            'draft' => 'secondary',
            'submitted' => 'info',
            'under_review' => 'primary',
            'revision_needed' => 'warning',
            'approved' => 'success',
            'rejected' => 'danger',
        ];
        
        return $colors[$this->status] ?? 'secondary';
    }

    public function getFormattedSubmissionDateAttribute()
    {
        return $this->submission_date ? $this->submission_date->format('d M Y H:i') : '-';
    }

    public function getFormattedReviewedAtAttribute()
    {
        return $this->reviewed_at ? $this->reviewed_at->format('d M Y H:i') : '-';
    }

    /**
     * Get submission date in WIB format
     */
    public function getSubmissionDateWibAttribute()
    {
        return DateTimeHelper::formatWithWIB($this->submission_date);
    }

    /**
     * Get reviewed date in WIB format
     */
    public function getReviewedAtWibAttribute()
    {
        return DateTimeHelper::formatWithWIB($this->reviewed_at);
    }

    /**
     * Get created date in WIB format
     */
    public function getCreatedAtWibAttribute()
    {
        return DateTimeHelper::formatWithWIB($this->created_at);
    }

    /**
     * Get first publication date formatted
     */
    public function getFirstPublicationDateFormattedAttribute()
    {
        return $this->first_publication_date ? 
               $this->first_publication_date->setTimezone('Asia/Jakarta')->format('d M Y') : 
               null;
    }

    // Add accessor for formatted address
    public function getFormattedAddressAttribute()
    {
        if (!$this->alamat) {
            return '-';
        }
        
        $address = $this->alamat;
        if ($this->kode_pos) {
            $address .= ' ' . $this->kode_pos;
        }
        
        return $address;
    }
}
