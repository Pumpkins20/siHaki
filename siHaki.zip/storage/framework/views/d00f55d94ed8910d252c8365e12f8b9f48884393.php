

<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent p-0 mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>" class="text-decoration-none">Kelola User</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.show', $user)); ?>" class="text-decoration-none"><?php echo e($user->nama); ?></a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1 text-gray-800">Edit User: <?php echo e($user->nama); ?></h1>
                    <p class="text-muted mb-0">Update informasi user dan pengaturan akun</p>
                </div>
                <div>
                    <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Form -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-pencil me-2"></i>Edit Informasi User
                    </h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST" id="editUserForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <!-- Basic Information -->
                        <div class="mb-4">
                            <h6 class="fw-bold text-secondary mb-3">
                                <i class="bi bi-person-badge me-2"></i>Informasi Dasar
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="nidn" class="form-label">NIDN</label>
                                        <input type="text" class="form-control bg-light" id="nidn" 
                                               value="<?php echo e($user->nidn); ?>" readonly>
                                        <div class="form-text">NIDN tidak dapat diubah</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="nama" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="nama" name="nama" value="<?php echo e(old('nama', $user->nama)); ?>" 
                                               placeholder="Masukkan nama lengkap" required>
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="username" name="username" value="<?php echo e(old('username', $user->username)); ?>" 
                                               placeholder="Username untuk login" required>
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <div class="form-text">Username harus unique</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" 
                                               placeholder="email@example.com" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">No. Telepon</label>
                                        <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="phone" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" 
                                               placeholder="Nomor telepon">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="program_studi" class="form-label">Program Studi <span class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="program_studi" name="program_studi" required>
                                            <option value="">Pilih Program Studi</option>
                                            <?php $__currentLoopData = App\Models\User::PROGRAM_STUDI_OPTIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prodi); ?>" <?php echo e(old('program_studi', $user->program_studi) == $prodi ? 'selected' : ''); ?>>
                                                    <?php echo e($prodi); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Department & Role -->
                        <div class="mb-4">
                            <h6 class="fw-bold text-secondary mb-3">
                                <i class="bi bi-building me-2"></i>Departemen & Role
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="department_id" class="form-label">Departemen <span class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="department_id" name="department_id" required>
                                            <option value="">Pilih Departemen</option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department->id); ?>" <?php echo e(old('department_id', $user->department_id) == $department->id ? 'selected' : ''); ?>>
                                                    <?php echo e($department->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="role" class="form-label">Role <span class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                id="role" name="role" required <?php echo e($user->id === Auth::id() ? 'disabled' : ''); ?>>
                                            <option value="">Pilih Role</option>
                                            <option value="user" <?php echo e(old('role', $user->role) == 'user' ? 'selected' : ''); ?>>Dosen</option>
                                            <option value="admin" <?php echo e(old('role', $user->role) == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                        </select>
                                        <?php if($user->id === Auth::id()): ?>
                                            <input type="hidden" name="role" value="<?php echo e($user->role); ?>">
                                            <div class="form-text text-warning">
                                                <i class="bi bi-exclamation-triangle me-1"></i>
                                                Anda tidak dapat mengubah role sendiri
                                            </div>
                                        <?php endif; ?>
                                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Account Settings -->
                        <div class="mb-4">
                            <h6 class="fw-bold text-secondary mb-3">
                                <i class="bi bi-gear me-2"></i>Pengaturan Akun
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="is_active" 
                                                   name="is_active" value="1" <?php echo e(old('is_active', $user->is_active) ? 'checked' : ''); ?>

                                                   <?php echo e($user->id === Auth::id() ? 'disabled' : ''); ?>>
                                            <label class="form-check-label" for="is_active">
                                                Akun Aktif
                                            </label>
                                        </div>
                                        <?php if($user->id === Auth::id()): ?>
                                            <input type="hidden" name="is_active" value="1">
                                            <div class="form-text text-warning">
                                                <i class="bi bi-exclamation-triangle me-1"></i>
                                                Anda tidak dapat menonaktifkan akun sendiri
                                            </div>
                                        <?php else: ?>
                                            <div class="form-text">User dapat login jika akun aktif</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="reset_password" 
                                                   name="reset_password" value="1">
                                            <label class="form-check-label" for="reset_password">
                                                Reset Password ke NIDN
                                            </label>
                                        </div>
                                        <div class="form-text">Centang untuk mereset password user ke NIDN default</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                            <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali
                            </a>
                            <div>
                                <button type="reset" class="btn btn-outline-warning me-2">
                                    <i class="bi bi-arrow-clockwise"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-success">
                                    <i class="bi bi-save"></i> Update User
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar Information -->
        <div class="col-xl-4 col-lg-5">
            <!-- Current User Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-person-circle me-2"></i>Informasi Saat Ini
                    </h6>
                </div>
                <div class="card-body">
                    <div class="text-center mb-3">
                        <?php if($user->foto && $user->foto !== 'default.png'): ?>
                            <img src="<?php echo e(asset('storage/profile_photos/' . $user->foto)); ?>" 
                                 alt="Profile Photo" class="rounded-circle mb-2" width="80" height="80">
                        <?php else: ?>
                            <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center text-white mx-auto mb-2" 
                                 style="width: 80px; height: 80px;">
                                <?php echo e(strtoupper(substr($user->nama, 0, 2))); ?>

                            </div>
                        <?php endif; ?>
                        <h6 class="mb-1"><?php echo e($user->nama); ?></h6>
                        <small class="text-muted"><?php echo e($user->program_studi); ?></small>
                    </div>
                    
                    <div class="small">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <td width="40%"><strong>NIDN:</strong></td>
                                <td><span class="font-monospace"><?php echo e($user->nidn); ?></span></td>
                            </tr>
                            <tr>
                                <td><strong>Username:</strong></td>
                                <td><span class="font-monospace"><?php echo e($user->username); ?></span></td>
                            </tr>
                            <tr>
                                <td><strong>Role:</strong></td>
                                <td>
                                    <?php if($user->role === 'admin'): ?>
                                        <span class="badge bg-danger">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">Dosen</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Status:</strong></td>
                                <td>
                                    <?php if($user->is_active): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Bergabung:</strong></td>
                                <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Activity Log -->
            <?php if($user->role === 'user'): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-activity me-2"></i>Aktivitas Terbaru
                    </h6>
                </div>
                <div class="card-body">
                    <div class="small">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Total Submission:</span>
                            <strong><?php echo e($user->submissions()->count()); ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Approved:</span>
                            <strong class="text-success"><?php echo e($user->submissions()->where('status', 'approved')->count()); ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Pending:</span>
                            <strong class="text-warning"><?php echo e($user->submissions()->whereIn('status', ['submitted', 'under_review'])->count()); ?></strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Rejected:</span>
                            <strong class="text-danger"><?php echo e($user->submissions()->where('status', 'rejected')->count()); ?></strong>
                        </div>
                    </div>
                    
                    <?php if($user->submissions()->exists()): ?>
                        <hr>
                        <div class="small">
                            <strong>Submission Terakhir:</strong><br>
                            <?php $lastSubmission = $user->submissions()->latest()->first(); ?>
                            <?php echo e(Str::limit($lastSubmission->title, 40)); ?><br>
                            <small class="text-muted"><?php echo e($lastSubmission->created_at->diffForHumans()); ?></small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Edit Guidelines -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-info-circle me-2"></i>Panduan Edit
                    </h6>
                </div>
                <div class="card-body">
                    <div class="small">
                        <h6 class="fw-bold">Yang Dapat Diubah:</h6>
                        <ul class="mb-3">
                            <li>Nama lengkap user</li>
                            <li>Username (harus unique)</li>
                            <li>Email user</li>
                            <li>Nomor telepon</li>
                            <li>Program studi</li>
                            <li>Departemen</li>
                            <li>Role user (kecuali untuk diri sendiri)</li>
                            <li>Status aktif/nonaktif</li>
                        </ul>
                        
                        <h6 class="fw-bold">Yang Tidak Dapat Diubah:</h6>
                        <ul class="mb-3">
                            <li>NIDN user</li>
                            <li>Tanggal bergabung</li>
                            <li>History submissions</li>
                        </ul>
                        
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            <strong>Perhatian:</strong> Anda tidak dapat mengubah role atau menonaktifkan akun sendiri.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form submission handling
    document.getElementById('editUserForm').addEventListener('submit', function(e) {
        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Memperbarui...';
        
        // Re-enable after 10 seconds if still processing
        setTimeout(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-save"></i> Update User';
        }, 10000);
    });

    // Phone number validation - only numbers
    document.getElementById('phone').addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9+\-\s]/g, '');
    });

    // Reset password confirmation
    document.getElementById('reset_password').addEventListener('change', function() {
        if (this.checked) {
            if (!confirm('Apakah Anda yakin ingin mereset password user ini ke NIDN default?')) {
                this.checked = false;
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.form-check-input:checked {
    background-color: #28a745;
    border-color: #28a745;
}

.border-top {
    border-top: 1px solid #dee2e6 !important;
}

.card-header {
    background-color: #f8f9fc;
}

.bg-light {
    background-color: #f8f9fa !important;
}

.font-monospace {
    font-family: 'Courier New', monospace;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siHaki\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>