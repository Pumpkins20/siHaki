<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>SiHaki | Sistem Informasi Hak Kekayaan Intelektual</title>
    <meta name="description" content="Sistem Informasi Hak Kekayaan Intelektual STMIK AMIKOM Surakarta">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('landing-page/css/pencipta.css')); ?>" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
       
    </style>
</head>

<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="<?php echo e(asset('landing-page/img/logo-amikom.png')); ?>" alt="Logo AMIKOM" style="height: 40px;">
</a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(route('beranda')); ?>">Beranda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(route('pencipta')); ?>">Pencipta</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('jenis_ciptaan')); ?>">Jenis Ciptaan</a>
                        </li>
                        <li class="nav-item">
                    <a class="nav-link" href="#">Panduan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

</body>
</html><?php /**PATH C:\laragon\www\siHaki\resources\views/panduan.blade.php ENDPATH**/ ?>