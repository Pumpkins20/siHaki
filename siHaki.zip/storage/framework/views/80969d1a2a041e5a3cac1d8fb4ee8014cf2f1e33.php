<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pencipta | SiHaki STMIK AMIKOM S</title>
    <meta name="description" content="Sistem Informasi Hak Kekayaan Intelektual STMIK AMIKOM Surakarta">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('landing-page/css/pencipta.css')); ?>" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>

    </style>
</head>

<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="<?php echo e(asset('landing-page/img/logo-amikom.png')); ?>" alt="Logo AMIKOM" style="height: 40px;">
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('beranda')); ?>">Beranda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="#pencipta">Pencipta</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('jenis_ciptaan')); ?>">Jenis Ciptaan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Filter Section -->
    <section class="filter-section">
        <div class="container">
            <div class="filter-card">
                <h4 class="filter-title">
                    <i class="bi bi-search me-2"></i>Cari Pencipta HKI
                </h4>
                <form method="GET" action="<?php echo e(route('pencipta')); ?>" class="search-form-horizontal">
                    <!-- Dropdown Cari Berdasarkan -->
                    <div class="form-group-flex">
                        <label for="searchBy" class="form-label">Cari Berdasarkan</label>
                        <select class="form-select" id="searchBy" name="search_by">
                            <option value="nama_pencipta" <?php echo e(request('search_by') == 'nama_pencipta' ? 'selected' : ''); ?>>Nama Pencipta</option>
                            <option value="jurusan" <?php echo e(request('search_by') == 'jurusan' ? 'selected' : ''); ?>>Jurusan/Program Studi</option>
                        </select>
                    </div>

                    <!-- Input Pencarian -->
                    <div class="form-group-flex search-input">
                        <label for="searchInput" class="form-label">Kata Kunci</label>
                        <input type="text" class="form-control" id="searchInput" name="q" 
                               value="<?php echo e(request('q')); ?>" placeholder="Masukkan kata kunci pencarian...">
                    </div>

                    <!-- Tombol Cari dan Show All -->
                    <div class="d-flex gap-2">
                        <button class="btn-search" type="submit">
                            <i class="bi bi-search me-2"></i>Cari
                        </button>
                        <!-- ✅ NEW: Show All Button -->
                        <?php if(request()->has('q') || request()->has('search_by')): ?>
                            <a href="<?php echo e(route('pencipta')); ?>" class="btn-show-all">
                                <i class="bi bi-list-ul me-2"></i>Lihat Semua
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Results Section -->
    <section class="results-section">
        <div class="container">
            <?php if(isset($results) && $results->count()): ?>
                <!-- Results Info -->
                <div class="mb-4">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Menampilkan <strong><?php echo e($results->firstItem()); ?>-<?php echo e($results->lastItem()); ?></strong> 
                        dari <strong><?php echo e($results->total()); ?></strong> pencipta
                        <?php if(isset($query) && $query): ?>
                            untuk pencarian "<strong><?php echo e($query); ?></strong>"
                        <?php endif; ?>
                        <?php if(isset($searchBy)): ?>
                            berdasarkan <strong><?php echo e($searchBy === 'nama_pencipta' ? 'Nama Pencipta' : 'Jurusan/Program Studi'); ?></strong>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Pencipta Cards -->
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pencipta-card">
                        <div class="d-flex align-items-start">
                            <!-- Avatar -->
                            <div class="pencipta-avatar">
                                <?php if($result->foto && $result->foto !== 'default.png'): ?>
                                    <img src="<?php echo e(asset('storage/profile_photos/' . $result->foto)); ?>" 
                                        alt="<?php echo e($result->nama); ?>"
                                        onerror="this.style.display='none'; this.parentElement.innerHTML='<?php echo e(substr($result->nama, 0, 2)); ?>';">
                                <?php else: ?>
                                    <?php echo e(substr($result->nama, 0, 2)); ?>

                                <?php endif; ?>
                            </div>
                            
                            <!-- Info -->
                            <div class="pencipta-info flex-grow-1">
                                <h5><?php echo e($result->nama); ?></h5>
                                <div class="institusi"><?php echo e($result->institusi ?? 'STMIK AMIKOM Surakarta'); ?></div>
                                <div class="jurusan"><?php echo e($result->jurusan ?? 'N/A'); ?></div>
                                
                                <div class="d-flex align-items-center gap-2 flex-wrap">
                                    <span class="total-hki-badge">
                                        <i class="bi bi-award me-1"></i><?php echo e($result->total_hki); ?> Pengajuan HKI
                                    </span>
                                    
                                    <?php if(isset($query) && $searchBy === 'nama_pencipta' && stripos($result->nama, $query) !== false): ?>
                                        <span class="search-match-badge">
                                            <i class="bi bi-check-circle me-1"></i>Sesuai pencarian nama
                                        </span>
                                    <?php elseif(isset($query) && $searchBy === 'jurusan' && stripos($result->jurusan, $query) !== false): ?>
                                        <span class="search-match-badge">
                                            <i class="bi bi-check-circle me-1"></i>Sesuai pencarian jurusan
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                
                                <?php if(isset($result->submissions) && $result->submissions->count() > 0): ?>
                                    <div class="recent-works">
                                        <small class="text-muted fw-bold">Pengajuan HKI Terbaru:</small>
                                        <ul class="list-unstyled mt-2 mb-0">
                                            <?php $__currentLoopData = $result->submissions->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <i class="bi bi-file-earmark-text me-1"></i>
                                                    <?php echo e(Str::limit($submission->title, 60)); ?>

                                                    <small class="text-primary">(<?php echo e($submission->created_at->format('Y')); ?>)</small>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($result->submissions->count() > 3): ?>
                                                <li class="text-muted">
                                                    <i class="bi bi-three-dots me-1"></i>
                                                    dan <?php echo e($result->submissions->count() - 3); ?> pengajuan lainnya
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Action Button -->
                            <div class="ms-3">
                                <a href="<?php echo e(route('detail_pencipta', $result->id)); ?>" class="btn btn-detail">
                                    <i class="bi bi-eye me-1"></i>Lihat Detail HKI
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- ✅ FIXED: Pagination with proper check -->
                <?php if($results->hasPages()): ?>
                    <div class="pagination-wrapper">
                        <nav aria-label="Pagination Navigation">
                            <?php echo e($results->links('custom.pagination')); ?>

                        </nav>
                    </div>
                <?php endif; ?>
                
            <?php elseif(isset($query) && $query): ?>
                <!-- No Results -->
                <div class="no-results">
                    <i class="bi bi-search"></i>
                    <h4>Data Tidak Ditemukan</h4>
                    <p>Tidak ada pencipta yang ditemukan untuk pencarian "<strong><?php echo e($query); ?></strong>"</p>
                    <?php if(isset($searchBy)): ?>
                        <p class="text-muted">berdasarkan <?php echo e($searchBy === 'nama_pencipta' ? 'Nama Pencipta' : 'Jurusan/Program Studi'); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo e(route('pencipta')); ?>" class="btn btn-outline-primary mt-3">
                        <i class="bi bi-arrow-left me-1"></i>Kembali ke Semua Pencipta
                    </a>
                </div>
            <?php else: ?>
                <!-- Default content when no search - Show all pencipta -->
                <div class="text-center mb-4">
                    <h4><i class="bi bi-people me-2"></i>Semua Pencipta HKI AMIKOM</h4>
                    <p class="text-muted">Daftar lengkap pencipta yang memiliki pengajuan HKI yang telah disetujui</p>
                </div>
                
                <!-- ✅ NEW: Auto load all users when no search -->
                <?php
                    // Get all users with approved submissions for display
                    $allUsers = \App\Models\User::select([
                        'users.id',
                        'users.nama',
                        'users.email',
                        'users.foto',
                        DB::raw('COUNT(DISTINCT hki_submissions.id) as total_hki')
                    ])
                    ->join('hki_submissions', 'users.id', '=', 'hki_submissions.user_id')
                    ->where('users.role', 'user')
                    ->where('hki_submissions.status', 'approved')
                    ->groupBy(['users.id', 'users.nama', 'users.email', 'users.foto'])
                    ->having('total_hki', '>', 0)
                    ->orderBy('total_hki', 'desc')
                    ->orderBy('users.nama')
                    ->paginate(6);
                    
                    // Load submissions for each user
                    $allUsers->getCollection()->transform(function ($user) {
                        $user->submissions = \App\Models\HkiSubmission::where('user_id', $user->id)
                            ->where('status', 'approved')
                            ->orderBy('created_at', 'desc')
                            ->limit(5)
                            ->get(['id', 'title', 'created_at']);
                        return $user;
                    });
                ?>
                
                <?php if($allUsers->count() > 0): ?>
                    <!-- Results Info -->
                    <div class="mb-4">
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            Menampilkan <strong><?php echo e($allUsers->firstItem()); ?>-<?php echo e($allUsers->lastItem()); ?></strong> 
                            dari <strong><?php echo e($allUsers->total()); ?></strong> pencipta
                        </div>
                    </div>
                    
                    <!-- Pencipta Cards -->
                    <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pencipta-card">
                            <div class="d-flex align-items-start">
                                <!-- Avatar -->
                                <div class="pencipta-avatar">
                                    <?php if($result->foto && $result->foto !== 'default.png'): ?>
                                        <img src="<?php echo e(asset('storage/profile_photos/' . $result->foto)); ?>" 
                                            alt="<?php echo e($result->nama); ?>"
                                            onerror="this.style.display='none'; this.parentElement.innerHTML='<?php echo e(substr($result->nama, 0, 2)); ?>';">
                                    <?php else: ?>
                                        <?php echo e(substr($result->nama, 0, 2)); ?>

                                    <?php endif; ?>
                                </div>
                                
                                <!-- Info -->
                                <div class="pencipta-info flex-grow-1">
                                    <h5><?php echo e($result->nama); ?></h5>
                                    <div class="institusi"><?php echo e($result->institusi ?? 'STMIK AMIKOM Surakarta'); ?></div>
                                    <div class="jurusan"><?php echo e($result->jurusan ?? 'N/A'); ?></div>
                                    
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        <span class="total-hki-badge">
                                            <i class="bi bi-award me-1"></i><?php echo e($result->total_hki); ?> Pengajuan HKI
                                        </span>
                                    </div>
                                    
                                    
                                    <?php if(isset($result->submissions) && $result->submissions->count() > 0): ?>
                                        <div class="recent-works">
                                            <small class="text-muted fw-bold">Pengajuan HKI Terbaru:</small>
                                            <ul class="list-unstyled mt-2 mb-0">
                                                <?php $__currentLoopData = $result->submissions->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <i class="bi bi-file-earmark-text me-1"></i>
                                                        <?php echo e(Str::limit($submission->title, 60)); ?>

                                                        <small class="text-primary">(<?php echo e($submission->created_at->format('Y')); ?>)</small>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($result->submissions->count() > 3): ?>
                                                    <li class="text-muted">
                                                        <i class="bi bi-three-dots me-1"></i>
                                                        dan <?php echo e($result->submissions->count() - 3); ?> pengajuan lainnya
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Action Button -->
                                <div class="ms-3">
                                    <a href="<?php echo e(route('detail_pencipta', $result->id)); ?>" class="btn btn-detail">
                                        <i class="bi bi-eye me-1"></i>Lihat Detail HKI
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination for all users -->
                    <?php if($allUsers->hasPages()): ?>
                        <div class="pagination-wrapper">
                            <nav aria-label="Pagination Navigation">
                                <?php echo e($allUsers->links('custom.pagination')); ?>

                            </nav>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-results">
                        <i class="bi bi-people"></i>
                        <h4>Belum Ada Data Pencipta</h4>
                        <p class="text-muted">Belum ada pencipta dengan pengajuan HKI yang disetujui</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Dynamic placeholder based on search type
        document.getElementById('searchBy').addEventListener('change', function() {
            const searchInput = document.getElementById('searchInput');
            const searchType = this.value;
            
            const placeholders = {
                'nama_pencipta': 'Contoh: Ahmad Fauzi, Sari Dewi',
                'jurusan': 'Contoh: S1 Informatika, D3 Manajemen Informatika'
            };
            
            searchInput.placeholder = placeholders[searchType] || 'Masukkan kata kunci pencarian...';
        });

        // Form enhancement
        document.querySelector('form').addEventListener('submit', function(e) {
            const searchInput = document.getElementById('searchInput');
            if (searchInput.value.trim() === '') {
                // Allow empty search to show all results
                return true;
            }
        });

        // Card hover effects
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.pencipta-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });
        });
    </script>
</body>
</html><?php /**PATH C:\laragon\www\siHaki\resources\views/pencipta.blade.php ENDPATH**/ ?>