

<?php $__env->startSection('title', 'Pengajuan HKI'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">Pengajuan HKI</h1>
                    <p class="text-muted">Kelola pengajuan HKI yang sedang dalam proses</p>
                </div>
                <a href="<?php echo e(route('user.submissions.create')); ?>" class="btn btn-success">
                    <i class="bi bi-plus-circle me-2"></i>Pengajuan Baru
                </a>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('user.submissions.index')); ?>">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label for="status" class="form-label">Status</label>
                                <select name="status" id="status" class="form-select">
                                    <option value="">Semua Status</option>
                                    
                                    <!-- <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option> -->
                                    <option value="submitted" <?php echo e(request('status') == 'submitted' ? 'selected' : ''); ?>>Submitted</option>
                                    <option value="under_review" <?php echo e(request('status') == 'under_review' ? 'selected' : ''); ?>>Under Review</option>
                                    <option value="revision_needed" <?php echo e(request('status') == 'revision_needed' ? 'selected' : ''); ?>>Revision Needed</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="creation_type" class="form-label">Jenis Ciptaan</label>
                                <select name="creation_type" id="creation_type" class="form-select">
                                    <option value="">Semua Jenis</option>
                                    <option value="program_komputer" <?php echo e(request('creation_type') == 'program_komputer' ? 'selected' : ''); ?>>Program Komputer</option>
                                    <option value="sinematografi" <?php echo e(request('creation_type') == 'sinematografi' ? 'selected' : ''); ?>>Sinematografi</option>
                                    <option value="buku" <?php echo e(request('creation_type') == 'buku' ? 'selected' : ''); ?>>Buku</option>
                                    <option value="poster_fotografi" <?php echo e(request('creation_type') == 'poster_fotografi' ? 'selected' : ''); ?>>Poster/Fotografi</option>
                                    <option value="alat_peraga" <?php echo e(request('creation_type') == 'alat_peraga' ? 'selected' : ''); ?>>Alat Peraga</option>
                                    <option value="basis_data" <?php echo e(request('creation_type') == 'basis_data' ? 'selected' : ''); ?>>Basis Data</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="search" class="form-label">Pencarian</label>
                                <input type="text" name="search" id="search" class="form-control" 
                                       placeholder="Cari judul..." value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Cari
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Submissions Table -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        Pengajuan Aktif (<?php echo e($submissions->total()); ?> pengajuan)
                    </h6>
                </div>
                <div class="card-body">
                    <?php if($submissions->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th width="25%">Judul</th>
                                        <th width="15%">Anggota Pencipta</th>
                                        <th width="15%">Jenis Ciptaan</th>
                                        <th width="15%">Status</th>
                                        <th width="15%">Tanggal Submit</th>
                                        <th width="15%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $statusColor = \App\Helpers\StatusHelper::getStatusColor($submission->status);
                                        $statusIcon = \App\Helpers\StatusHelper::getStatusIcon($submission->status);
                                        $statusName = \App\Helpers\StatusHelper::getStatusName($submission->status);
                                    ?>
                                    <tr>
                                        <td><?php echo e($submissions->firstItem() + $index); ?></td>
                                        <td>
                                            <div>
                                                <strong><?php echo e(Str::limit($submission->title, 40)); ?></strong>
                                                <br>
                                                <!-- <small class="text-muted"><?php echo e(Str::limit($submission->description, 60)); ?></small>
                                                <?php if($submission->member_count > 0): ?>
                                                    <br><span class="badge bg-info badge-sm"><?php echo e($submission->member_count); ?> anggota</span>
                                                <?php endif; ?> -->
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($submission->members->count() > 0): ?>
                                                <span class="badge bg-info"><?php echo e($submission->members->count()); ?> orang</span>
                                                <div class="small mt-1">
                                                    <strong><?php echo e($submission->members->where('is_leader', true)->first()->name ?? 'N/A'); ?></strong>
                                                    <?php if($submission->members->count() > 1): ?>
                                                        <br><small class="text-muted">+<?php echo e($submission->members->count() - 1); ?> lainnya</small>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                <?php echo e(ucfirst(str_replace('_', ' ', $submission->creation_type))); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($statusColor); ?>">
                                                <i class="bi bi-<?php echo e($statusIcon); ?> me-1"></i><?php echo e($statusName); ?>

                                            </span>
                                            <?php if($submission->status === 'revision_needed'): ?>
                                                <br><small class="text-warning"><i class="bi bi-exclamation-triangle"></i> Perlu revisi</small>
                                            <?php elseif($submission->status === 'draft'): ?>
                                                <br><small class="text-muted"><i class="bi bi-clock"></i> Belum submit</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <?php if($submission->submission_date): ?>
                                                    <strong><?php echo e($submission->submission_date->format('d M Y')); ?></strong>
                                                    <br><small class="text-muted"><?php echo e($submission->submission_date->format('H:i')); ?> WIB</small>
                                                <?php else: ?>
                                                    <span class="text-muted">Belum submit</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="btn-group-vertical" role="group">
                                                <a href="<?php echo e(route('user.submissions.show', $submission)); ?>" 
                                                   class="btn btn-sm btn-outline-primary mb-1" title="Lihat Detail">
                                                    <i class="bi bi-eye"></i> Detail
                                                </a>
                                                
                                                <?php if(in_array($submission->status, ['draft', 'revision_needed'])): ?>
                                                    <a href="<?php echo e(route('user.submissions.edit', $submission)); ?>" 
                                                       class="btn btn-sm btn-outline-warning mb-1" title="Edit">
                                                        <i class="bi bi-pencil"></i> Edit
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if($submission->status === 'draft'): ?>
                                                    <form action="<?php echo e(route('user.submissions.destroy', $submission)); ?>" 
                                                          method="POST" class="d-inline" 
                                                          onsubmit="return confirm('Yakin ingin menghapus submission ini?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                                            <i class="bi bi-trash"></i> Hapus
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="d-flex justify-content-center mt-3">
                            <?php echo e($submissions->appends(request()->query())->links('custom.pagination')); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted mb-3"></i>
                            <h5 class="text-muted">Belum ada pengajuan aktif</h5>
                            <p class="text-muted mb-4">Mulai ajukan HKI pertama Anda sekarang</p>
                            <a href="<?php echo e(route('user.submissions.create')); ?>" class="btn btn-success btn-lg">
                                <i class="bi bi-plus-circle me-2"></i>Buat Pengajuan Baru
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siHaki\resources\views/user/submissions/index.blade.php ENDPATH**/ ?>