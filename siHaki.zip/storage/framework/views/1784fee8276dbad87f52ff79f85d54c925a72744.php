


<?php $__env->startSection('title', 'Detail User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent p-0 mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>" class="text-decoration-none">Kelola User</a></li>
                    <li class="breadcrumb-item active"><?php echo e($user->nama); ?></li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1 text-gray-800">Detail User: <?php echo e($user->nama); ?></h1>
                    <p class="text-muted mb-0">Informasi lengkap tentang user</p>
                </div>
                <div>
                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-warning me-2">
                        <i class="bi bi-pencil"></i> Edit
                    </a>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- User Profile -->
        <div class="col-xl-4 col-lg-5">
            <!-- Profile Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-person-circle me-2"></i>Profile
                    </h6>
                </div>
                <div class="card-body text-center">
                    <div class="profile-photo-container mb-3">
                        <?php if($user->foto && $user->foto !== 'default.png'): ?>
                            <img src="<?php echo e(asset('storage/profile_photos/' . $user->foto)); ?>" 
                                 alt="Profile Photo" 
                                 class="profile-photo img-thumbnail">
                        <?php else: ?>
                            <div class="default-avatar">
                                <i class="bi bi-person-circle"></i>
                                <span class="initials"><?php echo e(strtoupper(substr($user->nama, 0, 2))); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <h5 class="mb-1"><?php echo e($user->nama); ?></h5>
                    <p class="text-muted mb-2"><?php echo e($user->program_studi); ?></p>
                    
                    <div class="mb-3">
                        <?php if($user->role === 'admin'): ?>
                            <span class="badge bg-danger fs-6">
                                <i class="bi bi-shield-check me-1"></i>Administrator
                            </span>
                        <?php else: ?>
                            <span class="badge bg-primary fs-6">
                                <i class="bi bi-person me-1"></i>Dosen
                            </span>
                        <?php endif; ?>
                        
                        <?php if($user->is_active): ?>
                            <span class="badge bg-success fs-6 ms-1">
                                <i class="bi bi-check-circle me-1"></i>Aktif
                            </span>
                        <?php else: ?>
                            <span class="badge bg-secondary fs-6 ms-1">
                                <i class="bi bi-x-circle me-1"></i>Nonaktif
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="text-start">
                        <p class="mb-1"><strong>NIDN:</strong> <?php echo e($user->nidn); ?></p>
                        <p class="mb-1"><strong>Username:</strong> <?php echo e($user->username); ?></p>
                        <p class="mb-1"><strong>Email:</strong> <?php echo e($user->email); ?></p>
                        <?php if($user->phone): ?>
                            <p class="mb-1"><strong>Telepon:</strong> <?php echo e($user->phone); ?></p>
                        <?php endif; ?>
                        <p class="mb-1"><strong>Departemen:</strong> <?php echo e($user->department->name ?? 'Tidak ada'); ?></p>
                        <p class="mb-0"><strong>Bergabung:</strong> <?php echo e($user->created_at->format('d M Y')); ?></p>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-lightning me-2"></i>Aksi Cepat
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-warning">
                            <i class="bi bi-pencil"></i> Edit User
                        </a>
                        <?php if($user->role === 'user'): ?>
                            <a href="<?php echo e(route('admin.submissions.index', ['user' => $user->id])); ?>" class="btn btn-info">
                                <i class="bi bi-file-earmark-text"></i> Lihat Submission
                            </a>
                        <?php endif; ?>
                        <button type="button" class="btn btn-outline-secondary" onclick="resetPassword()">
                            <i class="bi bi-key"></i> Reset Password
                        </button>
                        <?php if($user->id !== Auth::id()): ?>
                            <button type="button" class="btn <?php echo e($user->is_active ? 'btn-outline-warning' : 'btn-outline-success'); ?>" 
                                    onclick="toggleStatus()">
                                <i class="bi bi-<?php echo e($user->is_active ? 'pause' : 'play'); ?>"></i> 
                                <?php echo e($user->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Details -->
        <div class="col-xl-8 col-lg-7">
            <!-- Statistics -->
            <?php if($user->role === 'user'): ?>
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card border-start border-primary border-4 shadow-sm h-100">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Submission</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->submissions()->count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-file-earmark-text fs-2 text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-start border-success border-4 shadow-sm h-100">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Approved</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->submissions()->where('status', 'approved')->count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-check-circle fs-2 text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-start border-warning border-4 shadow-sm h-100">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($user->submissions()->whereIn('status', ['submitted', 'under_review'])->count()); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="bi bi-clock fs-2 text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Recent Submissions -->
            <?php if($user->role === 'user'): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary">Submission Terbaru</h6>
                    <a href="<?php echo e(route('admin.submissions.index', ['user' => $user->id])); ?>" class="btn btn-sm btn-primary">
                        <i class="bi bi-eye"></i> Lihat Semua
                    </a>
                </div>
                <div class="card-body">
                    <?php if($user->submissions()->exists()): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Judul</th>
                                        <th>Jenis</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $user->submissions()->latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(Str::limit($submission->title, 30)); ?></td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo e(ucfirst($submission->creation_type)); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($submission->status === 'approved' ? 'success' : ($submission->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                                <?php echo e(ucfirst(str_replace('_', ' ', $submission->status))); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($submission->created_at->format('d M Y')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.submissions.show', $submission)); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <i class="bi bi-inbox fs-1 text-muted"></i>
                            <p class="text-muted mt-2">Belum ada submission</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Account Information -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-info-circle me-2"></i>Informasi Akun
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td width="40%"><strong>User ID:</strong></td>
                                    <td><?php echo e($user->id); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>NIDN:</strong></td>
                                    <td><span class="font-monospace"><?php echo e($user->nidn); ?></span></td>
                                </tr>
                                <tr>
                                    <td><strong>Username:</strong></td>
                                    <td><span class="font-monospace"><?php echo e($user->username); ?></span></td>
                                </tr>
                                <tr>
                                    <td><strong>Role:</strong></td>
                                    <td>
                                        <?php if($user->role === 'admin'): ?>
                                            <span class="badge bg-danger">Administrator</span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">Dosen</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td width="40%"><strong>Status:</strong></td>
                                    <td>
                                        <?php if($user->is_active): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Nonaktif</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Bergabung:</strong></td>
                                    <td><?php echo e($user->created_at->format('d M Y H:i')); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Update Terakhir:</strong></td>
                                    <td><?php echo e($user->updated_at->format('d M Y H:i')); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Email Verified:</strong></td>
                                    <td>
                                        <?php if($user->email_verified_at): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Belum</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reset Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin mereset password untuk user <strong><?php echo e($user->nama); ?></strong>?</p>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    Password akan direset ke NIDN: <strong><?php echo e($user->nidn); ?></strong>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form action="<?php echo e(route('admin.users.reset-password', $user)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-key"></i> Reset Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Toggle Status Modal -->
<div class="modal fade" id="toggleStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($user->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?> User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin <?php echo e($user->is_active ? 'menonaktifkan' : 'mengaktifkan'); ?> user <strong><?php echo e($user->nama); ?></strong>?</p>
                <?php if($user->is_active): ?>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        User yang dinonaktifkan tidak dapat login ke sistem.
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form action="<?php echo e(route('admin.users.toggle-status', $user)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-<?php echo e($user->is_active ? 'warning' : 'success'); ?>">
                        <i class="bi bi-<?php echo e($user->is_active ? 'pause' : 'play'); ?>"></i> 
                        <?php echo e($user->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function resetPassword() {
    new bootstrap.Modal(document.getElementById('resetPasswordModal')).show();
}

function toggleStatus() {
    new bootstrap.Modal(document.getElementById('toggleStatusModal')).show();
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.profile-photo {
    width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 50%;
}

.default-avatar {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    margin: 0 auto;
}

.default-avatar i {
    font-size: 75px;
    color: white;
    opacity: 0.3;
}

.default-avatar .initials {
    position: absolute;
    font-size: 36px;
    font-weight: bold;
    color: white;
}

.border-start {
    border-left-width: 4px !important;
}

.font-monospace {
    font-family: 'Courier New', monospace;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siHaki\resources\views/admin/users/show.blade.php ENDPATH**/ ?>