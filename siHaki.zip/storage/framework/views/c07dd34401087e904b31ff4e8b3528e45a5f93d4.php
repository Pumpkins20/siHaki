

<?php $__env->startSection('title', 'Panduan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent p-0 mb-2">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.dashboard')); ?>" class="text-decoration-none">Dashboard</a></li>
                    <li class="breadcrumb-item active">Panduan</li>
                </ol>
            </nav>
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-1 text-gray-800">Panduan SiHaki</h1>
                    <p class="text-muted mb-0">Panduan lengkap penggunaan sistem dan FAQ</p>
                </div>
                <div>
                    <!-- <a href="<?php echo e(route('user.panduan.export-faq') . '?' . http_build_query(request()->query())); ?>" 
                       class="btn btn-success me-2">
                        <i class="bi bi-download"></i> Export FAQ
                    </a> -->
                    <a href="<?php echo e(route('user.submissions.create')); ?>" class="btn btn-success">
                        <i class="bi bi-plus-circle"></i> Ajukan HKI
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Access Cards -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-start border-primary border-4 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Download</div>
                            <div class="h6 mb-0 font-weight-bold text-gray-800">Panduan PDF</div>
                            <small class="text-muted">Panduan lengkap format PDF</small>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-file-earmark-pdf fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start border-success border-4 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">FAQ</div>
                            <div class="h6 mb-0 font-weight-bold text-gray-800"><?php echo e($filteredFaqs->count()); ?> Pertanyaan</div>
                            <small class="text-muted">Pertanyaan yang sering diajukan</small>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-question-circle fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start border-warning border-4 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Support</div>
                            <div class="h6 mb-0 font-weight-bold text-gray-800">Hubungi Kontak Kami</div>
                            <small class="text-muted">Kami siap membantu</small>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-headset fs-2 text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Content -->
        <div class="col-xl-8 col-lg-7">
            <!-- Download Guides Section -->
            <div class="card shadow mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-download me-2"></i>Download Panduan
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="card border-0 bg-light h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-shrink-0">
                                            <i class="bi bi-file-earmark-pdf fs-3 text-danger"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="card-title mb-1"><?php echo e($guide['title']); ?></h6>
                                            <p class="card-text small text-muted mb-2"><?php echo e($guide['description']); ?></p>
                                            <div class="small text-muted mb-3">
                                                <span class="me-3"><i class="bi bi-file-text me-1"></i><?php echo e($guide['pages']); ?> hal</span>
                                                <span class="me-3"><i class="bi bi-hdd me-1"></i><?php echo e($guide['size']); ?></span>
                                                <span><i class="bi bi-calendar me-1"></i><?php echo e(date('d M Y', strtotime($guide['updated']))); ?></span>
                                            </div>
                                            <a href="<?php echo e(route('user.panduan.download', $guide['file'])); ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="bi bi-download me-1"></i>Download
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- FAQ Section -->
            <div class="card shadow">
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6 class="m-0 fw-bold text-primary">
                            <i class="bi bi-question-circle me-2"></i>Frequently Asked Questions (FAQ)
                        </h6>
                        <small class="text-muted"><?php echo e($filteredFaqs->count()); ?> pertanyaan ditemukan</small>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Search and Filter -->
                    <form method="GET" action="<?php echo e(route('user.panduan.index')); ?>" class="mb-4">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <select name="category" class="form-select" onchange="this.form.submit()">
                                    <option value="all" <?php echo e($category == 'all' ? 'selected' : ''); ?>>Semua Kategori</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($category == $key ? 'selected' : ''); ?>>
                                            <?php echo e($name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Cari pertanyaan..." value="<?php echo e($search); ?>">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i>
                                </button>
                            </div>
                        </div>
                        <?php if($category !== 'all' || $search): ?>
                            <div class="mt-2">
                                <a href="<?php echo e(route('user.panduan.index')); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-arrow-clockwise"></i> Reset Filter
                                </a>
                            </div>
                        <?php endif; ?>
                    </form>

                    <!-- FAQ Accordion -->
                    <?php if($filteredFaqs->count() > 0): ?>
                        <div class="accordion" id="faqAccordion">
                            <?php $__currentLoopData = $filteredFaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($faq['id']); ?>">
                                    <button class="accordion-button <?php echo e($index !== 0 ? 'collapsed' : ''); ?>" 
                                            type="button" data-bs-toggle="collapse" 
                                            data-bs-target="#collapse<?php echo e($faq['id']); ?>" 
                                            aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>" 
                                            aria-controls="collapse<?php echo e($faq['id']); ?>">
                                        <div class="d-flex align-items-center w-100">
                                            <?php
                                                $categoryColors = [
                                                    'umum' => 'primary',
                                                    'pengajuan' => 'success', 
                                                    'dokumen' => 'warning',
                                                    'anggota' => 'info',
                                                    'status' => 'secondary',
                                                    'sertifikat' => 'danger'
                                                ];
                                                $color = $categoryColors[$faq['category']] ?? 'primary';
                                            ?>
                                            <span class="badge bg-<?php echo e($color); ?> me-2">
                                                <?php echo e($categories[$faq['category']]); ?>

                                            </span>
                                            <span class="flex-grow-1"><?php echo e($faq['question']); ?></span>
                                            <!--<?php if($faq['is_popular']): ?>
                                                 <span class="badge bg-warning text-dark ms-2">Populer</span>
                                            <?php endif; ?> -->
                                        </div>
                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($faq['id']); ?>" 
                                     class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>" 
                                     aria-labelledby="heading<?php echo e($faq['id']); ?>" 
                                     data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        <p class="mb-0"><?php echo e($faq['answer']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-search fs-1 text-muted"></i>
                            <h5 class="mt-2 text-muted">Tidak ada FAQ ditemukan</h5>
                            <p class="text-muted">Coba ubah kata kunci pencarian atau kategori</p>
                            <a href="<?php echo e(route('user.panduan.index')); ?>" class="btn btn-primary">
                                Lihat Semua FAQ
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-xl-4 col-lg-5">
           

            <!-- Quick Links -->
            <div class="card shadow mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-link-45deg me-2"></i>Link Cepat
                    </h6>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('user.submissions.create')); ?>" 
                           class="list-group-item list-group-item-action border-0">
                            <i class="bi bi-plus-circle text-success me-2"></i>Ajukan HKI Baru
                        </a>
                        <a href="<?php echo e(route('user.history.index')); ?>" 
                           class="list-group-item list-group-item-action border-0">
                            <i class="bi bi-clock-history text-info me-2"></i>Riwayat Pengajuan
                        </a>
                        <a href="<?php echo e(route('user.submissions.index')); ?>" 
                           class="list-group-item list-group-item-action border-0">
                            <i class="bi bi-file-earmark-text text-primary me-2"></i>Kelola Submission
                        </a>
                    </div>
                </div>
            </div>

            <!-- Contact Support -->
            <div class="card shadow">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 fw-bold text-primary">
                        <i class="bi bi-headset me-2"></i>Butuh Bantuan?
                    </h6>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <i class="bi bi-person-badge fs-1 text-primary mb-3"></i>
                        <h6>Tim Support SiHaki</h6>
                        <p class="small text-muted mb-3">
                            Kami siap membantu Anda untuk semua pertanyaan terkait pengajuan HKI.
                        </p>
                        
                        <div class="d-grid gap-2">
                             <a href="https://instagram.com/lppm_amikomsolo" class="btn btn-danger btn-sm" target="_blank">
                            <i class="bi bi-instagram me-1"></i> Instagram
                        </a>
                        <a href="https://wa.me/6289504696000" class="btn btn-success btn-sm" target="_blank">
                            <i class="bi bi-whatsapp me-1"></i> WhatsApp
                        </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality with delay
    const searchInput = document.querySelector('input[name="search"]');
    let searchTimeout;
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                // Auto-submit form after 1 second of no typing
                // this.form.submit();
            }, 1000);
        });
    }

    // Smooth scroll to FAQ if coming from external link
    if (window.location.hash) {
        const target = document.querySelector(window.location.hash);
        if (target) {
            setTimeout(() => {
                target.scrollIntoView({ behavior: 'smooth' });
            }, 100);
        }
    }

    // Track popular FAQ clicks
    document.querySelectorAll('.accordion-button').forEach(button => {
        button.addEventListener('click', function() {
            // Analytics tracking could be added here
            console.log('FAQ clicked:', this.textContent.trim());
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.accordion-button:not(.collapsed) {
    background-color: #f8f9fa;
    border-color: #dee2e6;
}

.accordion-button:focus {
    box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
    border-color: #28a745;
}

.list-group-item-action:hover {
    background-color: #f8f9fa;
}

.badge {
    font-size: 0.85em;
    padding: 0.5rem 0.8rem;
    min-width: 90px;
    text-align: center;
    display: inline-block;
    margin-right: 1rem;
    font-weight: 700; /* Bold text */
    color: #ffffff !important; /* Black text color */
    text-transform: uppercase; /* Optional: uppercase for more emphasis */
    letter-spacing: 0.5px; /* Optional: improved legibility */
}

.card-title {
    line-height: 1.3;
}

.border-start {
    border-left-width: 4px !important;
}

@media (max-width: 768px) {
    .card-body {
        padding: 1rem;
    }
    
    .accordion-button {
        padding: 0.75rem;
        font-size: 0.9rem;
    }
    
    .badge {
        font-size: 0.6em;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\siHaki\resources\views/user/panduan/index.blade.php ENDPATH**/ ?>